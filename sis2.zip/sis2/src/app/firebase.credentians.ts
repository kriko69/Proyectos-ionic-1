export const FIREBASE_CREDENTIALS={
    apiKey: "AIzaSyBgdexRkYK4C3z1WaU_z2TktXQ6WPppKS4",
      authDomain: "autocompartido-bd896.firebaseapp.com",
      databaseURL: "https://autocompartido-bd896.firebaseio.com",
      projectId: "autocompartido-bd896",
      storageBucket: "autocompartido-bd896.appspot.com",
      messagingSenderId: "396321778186"
  };
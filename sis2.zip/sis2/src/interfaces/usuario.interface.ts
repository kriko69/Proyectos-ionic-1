export interface Usuario{
    califconduc?:number;
    califpasa?:number;
    carnet:number;
    id?:number;
    nombre:string;
    apellido:string;
    pass1:string;
    tipo?:string;
}
import { Injectable } from "@angular/core";
import { AngularFireDatabase } from 'angularfire2/database';
import { Usuario } from '../interfaces/usuario.interface';

@Injectable()

export class firebaseService{
    
    private userRef;
    //    private shopingRef = this.db.list<Item>('shopping-list/nuevos');

    
    constructor(private db:AngularFireDatabase,){

    }

    definirUsusarioRef(aux:any)
    {
        this.userRef=this.db.list<Usuario>('Usuario/usuario-'+aux);
    }

    getUsuariarios()
    {
        return this.userRef;
    }

    add(usuario:Usuario)
    {
        return this.userRef.push(usuario);
    }
}
import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ToastController } from 'ionic-angular';

/**
 * Generated class for the TipoUsuarioPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */
import { AngularFireAuth } from 'angularfire2/auth';

@IonicPage()
@Component({
  selector: 'page-tipo-usuario',
  templateUrl: 'tipo-usuario.html',
})
export class TipoUsuarioPage {

  constructor(public navCtrl: NavController, public navParams: NavParams,
  private afAuth:AngularFireAuth, private toast:ToastController) {
  }

  ionViewDidLoad() {
    this.afAuth.authState.subscribe(data =>{
      if(data.email && data.uid)
      {
        this.toast.create({
          message:`bienvenido, ${data.email}`,
          duration:3000
        }).present();
      }
    });
  }

}
